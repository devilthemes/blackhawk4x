module.exports = {
  baseUrl: 'http://localhost',
  browserName: 'firefox'
};
